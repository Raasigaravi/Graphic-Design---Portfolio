# Raasigaravi R — Independent Creative Portfolio

This is a plain HTML, CSS and JavaScript portfolio. It does not require React, Node.js, a build step, or Emergent credits.

## 1. Preview on your computer
1. Extract the ZIP file.
2. Open the `raasi-independent-portfolio` folder.
3. Double-click `index.html` to preview it in your browser.

## 2. Update your contact details
Your email, LinkedIn and GitHub links are set at the top of `script.js` (and in the contact cards in `index.html`). Edit them there if they ever change, then refresh the browser.

## 3. Add your photo and creative assets
The About section currently has a designed placeholder. To use your own photo:
1. Put your image in the `assets` folder, for example `my-photo.jpg`.
2. In `index.html`, find `class="portrait-placeholder"` and replace that placeholder `<div>` with:
   `<img class="portrait-image" src="assets/my-photo.jpg" alt="Portrait of Raasigaravi">`
3. Add this CSS to `styles.css`:
   `.portrait-image{width:100%;height:480px;object-fit:cover;border-radius:25px;display:block}`

For real video work, replace the two video placeholder blocks with links or embedded video elements. Only show work you have actually made.

## 4. Publish on Netlify
1. Create/sign in to a Netlify account.
2. In the Netlify dashboard, choose **Add new site** / **Deploy manually** (wording may vary).
3. Drag the extracted project folder (the folder containing `index.html`, `styles.css`, and `script.js`) into the deploy area.
4. Netlify will provide a public website URL.
5. Test the live URL on desktop and mobile.

## Notes
- This is a fresh static recreation based on the supplied portfolio structure and visual direction. It is not a byte-for-byte export of the Emergent React project.
- The About portrait and video areas are placeholders until you add your chosen files.
- Flowstate is clearly labelled as a fictional, self-initiated concept campaign.
- Before publishing, verify your email, LinkedIn and GitHub links.
